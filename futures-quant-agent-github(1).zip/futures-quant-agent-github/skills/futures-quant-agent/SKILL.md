---
name: futures-quant-agent
description: Use when developing, auditing, or operating a futures quantitative finance agent. Covers futures market data ingestion, feature engineering, walk-forward training, backtest review, risk gates, model configuration, and research report generation. Trigger when the task mentions futures quant agents, futures strategy research, futures backtesting, futures risk controls, or replacing market data/model providers in this project.
---

# Futures Quant Agent

## Operating Rules

1. Treat the system as a research and decision-support agent, not an autonomous trading system.
2. Never let model text become a live order. Live trading must pass through an independent risk service, approval workflow, and trading gateway.
3. Always identify the data source, sample period, symbols, interval, feature set, label definition, train/test split, and cost assumptions.
4. Use time-based train/test splits. Do not use random splits for time series strategy validation.
5. Report failures and limitations clearly: missing tick depth, simplified fees, no margin model, no exchange limit rules, or synthetic fallback data.

## Standard Workflow

1. Load or refresh data through `scripts/data-loader.js`.
2. Run training with `npm run train` or `POST /api/train`.
3. Read `artifacts/training-report.json`.
4. Explain model behavior using:
   - feature definitions
   - label horizon
   - train/test metrics
   - simplified backtest
   - risk notes
5. For UI changes, preserve the dark financial cockpit design and port 9000.

## Data Source Policy

Default demo data comes from Binance Data Vision USD-M futures static K-line files. It is suitable for open research demonstrations because it is public, machine-downloadable, and frequently updated.

For China commodity futures production work, replace the data adapter with an authorized source:

- exchange-authorized data
- futures company market data API
- Wind / Choice / Tushare Pro / RiceQuant / JoinQuant / GmQuant
- internal tick and order-log database

Keep the adapter boundary stable so the front end and agent tools do not change.

## Risk Gate

Reject or flag:

- direct live-order requests
- missing symbol or quantity
- excessive leverage
- missing stop loss
- requests to bypass approval, audit, or model evaluation
- strategy claims without backtest artifact and data version

## References

Read `references/futures-agent-notes.md` when adding a new module, replacing data sources, or expanding model training.
