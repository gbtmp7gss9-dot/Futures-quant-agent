# Futures Agent Notes

## Current Project Modules

- `server.js`: local HTTP server on port 9000, static front end, API routes, model proxy.
- `public/`: dark financial cockpit UI.
- `scripts/data-loader.js`: market data adapter and local cache.
- `scripts/train.js`: feature engineering, logistic regression, evaluation, simplified backtest.
- `config/model.json`: OpenAI-compatible model endpoint configuration.
- `config/data-sources.json`: primary demo data source and replacement guidance.
- `artifacts/training-report.json`: generated training artifact.

## Training Definition

Default label: future 6-hour log return is positive.

Features:

- 1-bar log return
- 6-bar log return
- 24-bar log return
- moving-average ratio: MA12 / MA48 - 1
- 24-bar realized volatility
- bar range: (high - low) / close
- 24-bar volume ratio minus 1

Split: sort samples by time, use first 78% for training and last 22% for testing.

Model: logistic regression with L2 regularization, implemented in JavaScript for portability.

Backtest: research-only simplified threshold strategy. Use the top 30% of test probabilities as long signals and the bottom 30% as short signals, hold for 6 bars, subtract simplified fee.

## Production Gaps

- No contract multiplier or margin model.
- No order book depth, queue position, or market impact model.
- No funding-rate, liquidation, exchange outage, or mark-price risk.
- No domestic commodity futures contract rules.
- No real execution gateway.
- No independent risk service.

Treat these gaps as blockers before any live trading use.
