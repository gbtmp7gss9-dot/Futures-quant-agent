import { loadMarketData } from "./data-loader.js";
import { runTraining } from "./train.js";

const data = await loadMarketData({ maxMonths: 2 });
if (!data.rows.length) throw new Error("No market rows loaded");
const report = await runTraining({ maxMonths: 2, epochs: 8 });
if (!report.metrics?.test?.samples) throw new Error("Training report missing test metrics");
console.log(JSON.stringify({
  ok: true,
  mode: report.data.mode,
  rows: report.data.summary.totalRows,
  testSamples: report.metrics.test.samples,
  accuracy: report.metrics.test.accuracy
}, null, 2));
