import fs from "node:fs/promises";
import path from "node:path";
import { createWriteStream } from "node:fs";
import { Readable } from "node:stream";
import { finished } from "node:stream/promises";
import zlib from "node:zlib";

const ROOT = path.resolve(".");
const DATA_DIR = path.join(ROOT, "data");
const CONFIG_PATH = path.join(ROOT, "config", "data-sources.json");
const CACHE_PATH = path.join(DATA_DIR, "market-cache.json");

export async function readJson(filePath, fallback = null) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch (error) {
    if (fallback !== null) return fallback;
    throw error;
  }
}

export async function writeJson(filePath, data) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, JSON.stringify(data, null, 2), "utf8");
}

function monthZipUrl(baseUrl, symbol, interval, month) {
  return `${baseUrl}/monthly/klines/${symbol}/${interval}/${symbol}-${interval}-${month}.zip`;
}

function csvFileName(symbol, interval, month) {
  return `${symbol}-${interval}-${month}.csv`;
}

async function fetchZipBuffer(url) {
  const res = await fetch(url, {
    headers: {
      "User-Agent": "futures-quant-agent/0.1",
      "Accept": "application/zip,application/octet-stream,*/*"
    }
  });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status} for ${url}`);
  }
  const ab = await res.arrayBuffer();
  return Buffer.from(ab);
}

function extractCsvFromZip(buffer, expectedName) {
  // Minimal ZIP parser for standard Binance small static archives.
  let offset = 0;
  while (offset < buffer.length - 30) {
    const sig = buffer.readUInt32LE(offset);
    if (sig !== 0x04034b50) break;
    const method = buffer.readUInt16LE(offset + 8);
    const compressedSize = buffer.readUInt32LE(offset + 18);
    const fileNameLength = buffer.readUInt16LE(offset + 26);
    const extraLength = buffer.readUInt16LE(offset + 28);
    const nameStart = offset + 30;
    const name = buffer.slice(nameStart, nameStart + fileNameLength).toString("utf8");
    const dataStart = nameStart + fileNameLength + extraLength;
    const data = buffer.slice(dataStart, dataStart + compressedSize);
    if (name.endsWith(".csv") && (!expectedName || name === expectedName)) {
      if (method === 0) return data.toString("utf8");
      if (method === 8) return zlib.inflateRawSync(data).toString("utf8");
      throw new Error(`Unsupported ZIP compression method ${method}`);
    }
    offset = dataStart + compressedSize;
  }
  throw new Error(`CSV not found in ZIP${expectedName ? `: ${expectedName}` : ""}`);
}

function parseKlineCsv(csv, symbol, interval, sourceUrl) {
  const rows = [];
  for (const line of csv.trim().split(/\r?\n/)) {
    if (!line || line.startsWith("open_time")) continue;
    const cols = line.split(",");
    if (cols.length < 12) continue;
    const openTime = Number(cols[0]);
    if (!Number.isFinite(openTime)) continue;
    rows.push({
      symbol,
      interval,
      openTime,
      openTimeIso: new Date(openTime).toISOString(),
      open: Number(cols[1]),
      high: Number(cols[2]),
      low: Number(cols[3]),
      close: Number(cols[4]),
      volume: Number(cols[5]),
      closeTime: Number(cols[6]),
      quoteVolume: Number(cols[7]),
      trades: Number(cols[8]),
      takerBuyBaseVolume: Number(cols[9]),
      takerBuyQuoteVolume: Number(cols[10]),
      sourceUrl
    });
  }
  return rows;
}

function syntheticSeries(symbols, months, interval) {
  const start = Date.UTC(2025, 6, 1, 0, 0, 0);
  const hours = Math.max(24 * 300, months.length * 24 * 28);
  return symbols.flatMap((symbol, si) => {
    let price = 1800 + si * 420;
    const rows = [];
    for (let i = 0; i < hours; i += 1) {
      const t = start + i * 3600000;
      const seasonal = Math.sin(i / 45 + si) * 0.006;
      const trend = Math.sin(i / 260 + si * 0.7) * 0.002;
      const shock = Math.sin(i * 13.17 + si) * 0.003 + Math.cos(i * 3.71) * 0.0015;
      const ret = seasonal + trend + shock;
      const open = price;
      const close = Math.max(1, price * (1 + ret));
      const high = Math.max(open, close) * (1 + Math.abs(ret) * 0.65 + 0.001);
      const low = Math.min(open, close) * (1 - Math.abs(ret) * 0.65 - 0.001);
      const volume = Math.round(1200 + 300 * Math.abs(Math.sin(i / 11 + si)) + si * 120);
      rows.push({
        symbol,
        interval,
        openTime: t,
        openTimeIso: new Date(t).toISOString(),
        open,
        high,
        low,
        close,
        volume,
        closeTime: t + 3599999,
        quoteVolume: volume * close,
        trades: Math.round(volume / 4),
        takerBuyBaseVolume: volume * (0.45 + 0.1 * Math.sin(i / 17)),
        takerBuyQuoteVolume: volume * close * 0.5,
        sourceUrl: "synthetic:fallback"
      });
      price = close;
    }
    return rows;
  });
}

export async function loadMarketData({ refresh = false, maxMonths = null } = {}) {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const config = await readJson(CONFIG_PATH);
  const source = config.primary;
  const months = maxMonths ? source.months.slice(-maxMonths) : source.months;
  if (!refresh) {
    try {
      const cached = await readJson(CACHE_PATH);
      const cachedMonths = cached?.request?.months?.join("|");
      const requestedMonths = months.join("|");
      const cachedSymbols = cached?.request?.symbols?.join("|");
      const requestedSymbols = source.symbols.join("|");
      if (cached?.rows?.length && cachedMonths === requestedMonths && cachedSymbols === requestedSymbols) return cached;
    } catch {
      // fall through
    }
  }

  const rows = [];
  const failures = [];

  for (const symbol of source.symbols) {
    for (const month of months) {
      const url = monthZipUrl(source.baseUrl, symbol, source.interval, month);
      try {
        const zip = await fetchZipBuffer(url);
        const csv = extractCsvFromZip(zip, csvFileName(symbol, source.interval, month));
        rows.push(...parseKlineCsv(csv, symbol, source.interval, url));
      } catch (error) {
        failures.push({ symbol, month, url, error: error.message });
      }
    }
  }

  let finalRows = rows.sort((a, b) => a.symbol.localeCompare(b.symbol) || a.openTime - b.openTime);
  let mode = "downloaded";
  if (finalRows.length < source.symbols.length * 1000) {
    finalRows = syntheticSeries(source.symbols, months, source.interval);
    mode = "synthetic-fallback";
  }

  const cache = {
    generatedAt: new Date().toISOString(),
    mode,
    request: {
      symbols: source.symbols,
      interval: source.interval,
      months
    },
    source,
    rows: finalRows,
    failures,
    summary: summarizeRows(finalRows)
  };
  await writeJson(CACHE_PATH, cache);
  return cache;
}

export function summarizeRows(rows) {
  const bySymbol = {};
  for (const r of rows) {
    const s = bySymbol[r.symbol] ??= {
      symbol: r.symbol,
      rows: 0,
      first: r.openTimeIso,
      last: r.openTimeIso,
      minClose: Infinity,
      maxClose: -Infinity,
      avgVolume: 0
    };
    s.rows += 1;
    s.first = r.openTimeIso < s.first ? r.openTimeIso : s.first;
    s.last = r.openTimeIso > s.last ? r.openTimeIso : s.last;
    s.minClose = Math.min(s.minClose, r.close);
    s.maxClose = Math.max(s.maxClose, r.close);
    s.avgVolume += r.volume;
  }
  for (const s of Object.values(bySymbol)) {
    s.avgVolume = s.rows ? s.avgVolume / s.rows : 0;
    s.minClose = Number(s.minClose.toFixed(4));
    s.maxClose = Number(s.maxClose.toFixed(4));
    s.avgVolume = Number(s.avgVolume.toFixed(2));
  }
  return {
    totalRows: rows.length,
    symbols: Object.values(bySymbol)
  };
}

export { CACHE_PATH, CONFIG_PATH };
