import path from "node:path";
import { loadMarketData, summarizeRows, writeJson } from "./data-loader.js";

const ARTIFACT_PATH = path.resolve("artifacts", "training-report.json");

function sigmoid(x) {
  if (x < -40) return 0;
  if (x > 40) return 1;
  return 1 / (1 + Math.exp(-x));
}

function mean(values) {
  return values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
}

function std(values) {
  if (values.length < 2) return 0;
  const m = mean(values);
  return Math.sqrt(mean(values.map((x) => (x - m) ** 2)));
}

function sma(arr, idx, n, key = "close") {
  if (idx < n) return null;
  let sum = 0;
  for (let i = idx - n + 1; i <= idx; i += 1) sum += arr[i][key];
  return sum / n;
}

function rollingStdReturns(arr, idx, n) {
  if (idx < n + 1) return null;
  const rets = [];
  for (let i = idx - n + 1; i <= idx; i += 1) {
    rets.push(Math.log(arr[i].close / arr[i - 1].close));
  }
  return std(rets);
}

function groupBySymbol(rows) {
  const map = new Map();
  for (const row of rows) {
    if (!map.has(row.symbol)) map.set(row.symbol, []);
    map.get(row.symbol).push(row);
  }
  for (const arr of map.values()) arr.sort((a, b) => a.openTime - b.openTime);
  return map;
}

function buildDataset(rows) {
  const samples = [];
  for (const [symbol, arr] of groupBySymbol(rows)) {
    for (let i = 50; i < arr.length - 6; i += 1) {
      const r = arr[i];
      const ret1 = Math.log(arr[i].close / arr[i - 1].close);
      const ret6 = Math.log(arr[i].close / arr[i - 6].close);
      const ret24 = Math.log(arr[i].close / arr[i - 24].close);
      const ma12 = sma(arr, i, 12);
      const ma48 = sma(arr, i, 48);
      const vol24 = rollingStdReturns(arr, i, 24);
      const range = (r.high - r.low) / r.close;
      const volumeRatio = r.volume / (sma(arr, i, 24, "volume") || r.volume);
      const futureRet = Math.log(arr[i + 6].close / r.close);
      samples.push({
        symbol,
        time: r.openTimeIso,
        x: [
          ret1,
          ret6,
          ret24,
          ma12 && ma48 ? ma12 / ma48 - 1 : 0,
          vol24 || 0,
          range,
          volumeRatio - 1
        ],
        y: futureRet > 0 ? 1 : 0,
        futureRet
      });
    }
  }
  samples.sort((a, b) => a.time.localeCompare(b.time) || a.symbol.localeCompare(b.symbol));
  return samples;
}

function standardize(train, test) {
  const cols = train[0].x.length;
  const mu = [];
  const sigma = [];
  for (let c = 0; c < cols; c += 1) {
    const values = train.map((s) => s.x[c]);
    mu[c] = mean(values);
    sigma[c] = std(values) || 1;
  }
  const tx = (sample) => ({
    ...sample,
    x: sample.x.map((v, i) => (v - mu[i]) / sigma[i])
  });
  return { train: train.map(tx), test: test.map(tx), mu, sigma };
}

function fitLogistic(train, { epochs = 80, lr = 0.035, l2 = 0.001 } = {}) {
  const dim = train[0].x.length;
  const w = Array(dim).fill(0);
  let b = 0;
  const losses = [];
  for (let epoch = 0; epoch < epochs; epoch += 1) {
    let loss = 0;
    const grad = Array(dim).fill(0);
    let gb = 0;
    for (const s of train) {
      const z = b + s.x.reduce((acc, v, i) => acc + w[i] * v, 0);
      const p = sigmoid(z);
      const err = p - s.y;
      loss += -(s.y * Math.log(p + 1e-9) + (1 - s.y) * Math.log(1 - p + 1e-9));
      for (let i = 0; i < dim; i += 1) grad[i] += err * s.x[i] + l2 * w[i];
      gb += err;
    }
    for (let i = 0; i < dim; i += 1) w[i] -= (lr * grad[i]) / train.length;
    b -= (lr * gb) / train.length;
    losses.push(Number((loss / train.length).toFixed(6)));
  }
  return { w, b, losses };
}

function predict(model, sample) {
  return sigmoid(model.b + sample.x.reduce((acc, v, i) => acc + model.w[i] * v, 0));
}

function evaluate(model, samples) {
  let correct = 0;
  let tp = 0;
  let fp = 0;
  let tn = 0;
  let fn = 0;
  const scored = samples.map((s) => ({ ...s, p: predict(model, s) }));
  for (const s of scored) {
    const pred = s.p >= 0.5 ? 1 : 0;
    if (pred === s.y) correct += 1;
    if (pred === 1 && s.y === 1) tp += 1;
    if (pred === 1 && s.y === 0) fp += 1;
    if (pred === 0 && s.y === 0) tn += 1;
    if (pred === 0 && s.y === 1) fn += 1;
  }
  const longThreshold = quantile(scored.map((s) => s.p), 0.7);
  const shortThreshold = quantile(scored.map((s) => s.p), 0.3);
  const longSignals = scored.filter((s) => s.p >= longThreshold);
  const shortSignals = scored.filter((s) => s.p <= shortThreshold);
  return {
    samples: samples.length,
    accuracy: Number((correct / samples.length).toFixed(4)),
    precisionLong: Number((tp / Math.max(1, tp + fp)).toFixed(4)),
    recallLong: Number((tp / Math.max(1, tp + fn)).toFixed(4)),
    confusion: { tp, fp, tn, fn },
    avgFutureReturnLongSignal: Number(mean(longSignals.map((s) => s.futureRet)).toFixed(6)),
    avgFutureReturnShortSignal: Number(mean(shortSignals.map((s) => -s.futureRet)).toFixed(6)),
    longSignalCount: longSignals.length,
    shortSignalCount: shortSignals.length,
    signalThresholds: {
      long: Number(longThreshold.toFixed(4)),
      short: Number(shortThreshold.toFixed(4))
    }
  };
}

function quantile(values, q) {
  const sorted = [...values].sort((a, b) => a - b);
  if (!sorted.length) return 0.5;
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  return sorted[base + 1] === undefined ? sorted[base] : sorted[base] + rest * (sorted[base + 1] - sorted[base]);
}

function backtest(model, samples) {
  const probabilities = samples.map((s) => predict(model, s));
  const longThreshold = quantile(probabilities, 0.7);
  const shortThreshold = quantile(probabilities, 0.3);
  let equity = 1;
  let peak = 1;
  let maxDrawdown = 0;
  const fee = 0.0004;
  const returns = [];
  const trades = [];
  const timeBuckets = new Map();
  for (const s of samples) {
    const p = predict(model, s);
    let position = 0;
    if (p >= longThreshold) position = 1;
    if (p <= shortThreshold) position = -1;
    if (position === 0) {
      continue;
    }
    const r = position * s.futureRet - fee;
    if (!timeBuckets.has(s.time)) timeBuckets.set(s.time, []);
    timeBuckets.get(s.time).push(r);
    trades.push({ symbol: s.symbol, time: s.time, position, probability: Number(p.toFixed(4)), futureRet: Number(s.futureRet.toFixed(6)), pnl: Number(r.toFixed(6)) });
  }
  for (const time of [...timeBuckets.keys()].sort()) {
    const bucketReturn = mean(timeBuckets.get(time));
    equity *= Math.exp(bucketReturn);
    peak = Math.max(peak, equity);
    maxDrawdown = Math.max(maxDrawdown, 1 - equity / peak);
    returns.push(bucketReturn);
  }
  const avg = mean(returns);
  const sd = std(returns);
  const sharpe = sd ? (avg / sd) * Math.sqrt(365 * 4) : 0;
  return {
    startEquity: 1,
    endEquity: Number(equity.toFixed(4)),
    totalReturn: Number((equity - 1).toFixed(4)),
    maxDrawdown: Number(maxDrawdown.toFixed(4)),
    sharpeLike: Number(sharpe.toFixed(3)),
    trades: trades.length,
    feeAssumption: fee,
    signalThresholds: {
      long: Number(longThreshold.toFixed(4)),
      short: Number(shortThreshold.toFixed(4))
    },
    recentTrades: trades.slice(-20)
  };
}

export async function runTraining(options = {}) {
  const cache = await loadMarketData({ refresh: options.refresh === true, maxMonths: options.maxMonths ?? null });
  const samples = buildDataset(cache.rows);
  const split = Math.floor(samples.length * 0.78);
  const rawTrain = samples.slice(0, split);
  const rawTest = samples.slice(split);
  const standardized = standardize(rawTrain, rawTest);
  const model = fitLogistic(standardized.train, options);
  const trainEval = evaluate(model, standardized.train);
  const testEval = evaluate(model, standardized.test);
  const bt = backtest(model, standardized.test);
  const report = {
    generatedAt: new Date().toISOString(),
    purpose: "期货量化智能体训练演示：基于 1h K 线构建短周期方向概率模型，输出研究信号和回测诊断。",
    data: {
      mode: cache.mode,
      sourceName: cache.source.name,
      interval: cache.source.interval,
      symbols: cache.source.symbols,
      summary: summarizeRows(cache.rows),
      failures: cache.failures
    },
    featureEngineering: {
      label: "未来 6 根 1h K 线收益是否为正",
      features: ["ret1", "ret6", "ret24", "ma12/ma48-1", "volatility24", "barRange", "volumeRatio24-1"],
      split: "按时间排序，前 78% 训练，后 22% 测试，避免随机切分造成时间泄露。",
      standardization: "只用训练集均值和标准差标准化，再应用到测试集。"
    },
    model: {
      type: "logistic-regression",
      epochs: options.epochs ?? 80,
      learningRate: options.lr ?? 0.035,
      l2: options.l2 ?? 0.001,
      weights: model.w.map((x) => Number(x.toFixed(6))),
      bias: Number(model.b.toFixed(6)),
      lossStart: model.losses[0],
      lossEnd: model.losses.at(-1),
      lossCurve: model.losses
    },
    metrics: { train: trainEval, test: testEval },
    backtest: bt,
    riskNotes: [
      "这是研究级模型，不得直接用于实盘下单。",
      "回测使用简化费用和 6 小时持有假设，没有盘口深度、保证金、强平、资金费率和交易所限价约束。",
      "生产系统必须接入独立风控、模拟盘、审批和交易网关。"
    ]
  };
  await writeJson(ARTIFACT_PATH, report);
  return report;
}

const isCli = process.argv[1] && path.basename(process.argv[1]) === "train.js";

if (isCli) {
  const report = await runTraining({ refresh: process.argv.includes("--refresh") });
  console.log(JSON.stringify({
    rows: report.data.summary.totalRows,
    samples: report.metrics.test.samples + report.metrics.train.samples,
    accuracy: report.metrics.test.accuracy,
    backtest: report.backtest,
    artifact: ARTIFACT_PATH
  }, null, 2));
}
