from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from pathlib import Path
import zipfile

OUT = Path("期货量化智能体开发过程说明.docx")
FONT = "Microsoft YaHei"
BLUE = RGBColor(46, 116, 181)
MUTED = RGBColor(96, 96, 96)


def set_font(run, size=11, bold=False, color=None):
    run.font.name = FONT
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), FONT)
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = color


def para(doc, text, size=11, bold=False, color=None, before=0, after=6, heading=None):
    p = doc.add_heading("", level=heading) if heading else doc.add_paragraph()
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    r = p.add_run(text)
    set_font(r, size=size, bold=bold, color=color)
    return p


def bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text)
    set_font(r, size=10.5)


def shade_cell(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def add_table(doc, headers, rows):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.style = "Table Grid"
    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]
        shade_cell(cell, "E8EEF5")
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p = cell.paragraphs[0]
        r = p.add_run(h)
        set_font(r, size=9.5, bold=True)
    for row in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p = cells[i].paragraphs[0]
            r = p.add_run(str(value))
            set_font(r, size=9.2)
    para(doc, "", after=4)


doc = Document()
sec = doc.sections[0]
sec.page_width = Inches(8.5)
sec.page_height = Inches(11)
sec.top_margin = sec.right_margin = sec.bottom_margin = sec.left_margin = Inches(1)
doc.styles["Normal"].font.name = FONT
doc.styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
doc.styles["Normal"].font.size = Pt(11)

para(doc, "期货量化智能体开发过程说明", size=22, bold=True, after=10)
para(doc, "本说明记录当前文件夹内已构建的期货量化智能体 MVP：数据来源、训练过程、智能体架构、前端模块、模型配置和后续扩展方式。", size=11.5, color=MUTED, after=14)

para(doc, "1. 已完成内容", size=15, bold=True, color=BLUE, before=12, heading=1)
for item in [
    "创建本地 Node.js 服务，默认端口 9000，运行命令为 npm start。",
    "创建深色金融风格前端，包含总览、智能体对话、数据、训练、风控、模型配置六个模块。",
    "接入 OpenAI-compatible 大模型配置，默认使用本地占位配置；用户可在前端模型配置页替换为自己的模型服务。",
    "接入 Binance Data Vision USD-M Futures 静态 K 线作为开源期货训练数据源。",
    "实现特征工程、逻辑回归训练、时间序列切分、测试集评估和简化回测。",
    "创建 futures-quant-agent Skill，用于后续开发、审计和扩展。"
]:
    bullet(doc, item)

para(doc, "2. 数据来源与样本要求", size=15, bold=True, color=BLUE, before=12, heading=1)
para(doc, "当前使用 Binance Data Vision 的 USD-M futures monthly klines。配置文件为 config/data-sources.json，默认合约包含 BTCUSDT、ETHUSDT、BNBUSDT、SOLUSDT、XRPUSDT、DOGEUSDT、ADAUSDT、LINKUSDT，频率为 1h，月份覆盖 2025-07 至 2026-05。按配置估算，完整下载后约 8 个合约 x 约 11 个月 x 每月约 720 根 K 线，数量级约 6 万行，足够支撑 MVP 级方向模型训练、特征检验和界面演示。", after=8)
add_table(doc, ["项目", "说明"], [
    ["数据文件", "data/market-cache.json"],
    ["数据源", "https://data.binance.vision/data/futures/um/monthly/klines/"],
    ["训练产物", "artifacts/training-report.json"],
    ["生产替换", "国内商品期货应替换为交易所授权数据、行情商接口或内部数据库"]
])

para(doc, "3. 训练过程", size=15, bold=True, color=BLUE, before=12, heading=1)
for item in [
    "读取并缓存 K 线数据，按合约和时间排序。",
    "构造特征：1h、6h、24h 对数收益，MA12/MA48，24h 波动率，K 线振幅，24h 成交量比。",
    "定义标签：未来 6 根 1h K 线收益是否为正。",
    "按时间排序切分：前 78% 训练，后 22% 测试，避免时间序列随机切分造成信息泄露。",
    "只用训练集均值和标准差做标准化，再应用到测试集。",
    "训练逻辑回归模型，使用 L2 正则，输出权重、损失曲线、准确率、Precision/Recall。",
    "简化回测：按测试集概率分布取上 30% 做多、下 30% 做空，持有 6 根 K 线，扣除研究级手续费假设。"
]:
    bullet(doc, item)

para(doc, "4. 智能体架构", size=15, bold=True, color=BLUE, before=12, heading=1)
add_table(doc, ["模块", "文件", "职责"], [
    ["HTTP 服务", "server.js", "静态页面、API、模型代理、训练调用、风控检查"],
    ["前端界面", "public/index.html / styles.css / app.js", "深色金融工作台和交互模块"],
    ["数据适配", "scripts/data-loader.js", "下载、解析、缓存、摘要数据"],
    ["训练逻辑", "scripts/train.js", "特征、训练、评估、回测"],
    ["模型配置", "config/model.json", "baseUrl、apiKey、model、temperature、systemPrompt"],
    ["Skill", "skills/futures-quant-agent", "固化开发和风控工作流"]
])

para(doc, "5. 风控边界", size=15, bold=True, color=BLUE, before=12, heading=1)
for item in [
    "当前智能体只能做研究辅助、报告解释、模拟风控检查，不能直接下实盘订单。",
    "风控接口会拦截实盘意图、缺少止损、过高杠杆和缺少数量等情况。",
    "实盘前必须补充独立风控服务、交易网关、账户权限隔离、审计日志、应急停止和人工审批。"
]:
    bullet(doc, item)

para(doc, "6. 使用方式", size=15, bold=True, color=BLUE, before=12, heading=1)
for item in [
    "启动：npm start",
    "访问：http://localhost:9000",
    "训练：前端点击运行训练，或命令行 npm run train。",
    "测试：npm run smoke。"
]:
    bullet(doc, item)

para(doc, "7. 后续建议", size=15, bold=True, color=BLUE, before=12, heading=1)
for item in [
    "替换为国内商品期货授权数据，并补充合约乘数、保证金、涨跌停、交易日历、换月规则。",
    "把训练模块迁移为 Python/pandas/polars + 专业回测引擎，同时保留 API 契约。",
    "增加实验注册表、模型版本、特征版本、数据版本和策略评审审批流。",
    "接入模拟盘和独立风险服务，再考虑小资金实盘。"
]:
    bullet(doc, item)

doc.core_properties.title = "期货量化智能体开发过程说明"
doc.core_properties.author = "Codex"
doc.save(OUT)
with zipfile.ZipFile(OUT) as zf:
    assert "word/document.xml" in zf.namelist()
print(OUT.resolve())
