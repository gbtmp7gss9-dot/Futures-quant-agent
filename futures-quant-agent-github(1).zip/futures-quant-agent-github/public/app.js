const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];

let state = {
  data: null,
  training: null,
  messages: []
};

async function api(path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const text = await res.text();
  const json = text ? JSON.parse(text) : {};
  if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
  return json;
}

function fmtPct(x) {
  return typeof x === "number" ? `${(x * 100).toFixed(2)}%` : "--";
}

function setHealth(ok, text) {
  $("#health-dot").className = `dot ${ok ? "ok" : "bad"}`;
  $("#health-text").textContent = text;
}

function switchPanel(id) {
  $$(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.panel === id));
  $$(".panel").forEach((p) => p.classList.toggle("active", p.id === id));
}

async function loadHealth() {
  try {
    await api("/api/health");
    setHealth(true, "服务在线");
  } catch {
    setHealth(false, "服务离线");
  }
}

async function loadData(refresh = false) {
  const data = await api(`/api/data/summary${refresh ? "?refresh=1" : ""}`);
  state.data = data;
  $("#data-mode").textContent = data.mode;
  $("#total-rows").textContent = data.summary.totalRows.toLocaleString();
  $("#source-name").textContent = data.source.name;
  const select = $("#symbol-select");
  select.innerHTML = data.summary.symbols.map((s) => `<option value="${s.symbol}">${s.symbol}</option>`).join("");
  renderSymbolTable(data.summary.symbols);
  await loadCandles(select.value || data.summary.symbols[0]?.symbol);
}

function renderSymbolTable(symbols) {
  $("#symbol-table").innerHTML = `
    <table>
      <thead><tr><th>合约</th><th>样本数</th><th>开始</th><th>结束</th><th>最低收盘</th><th>最高收盘</th><th>均量</th></tr></thead>
      <tbody>${symbols.map((s) => `
        <tr><td>${s.symbol}</td><td>${s.rows.toLocaleString()}</td><td>${s.first.slice(0, 10)}</td><td>${s.last.slice(0, 10)}</td><td>${s.minClose}</td><td>${s.maxClose}</td><td>${s.avgVolume}</td></tr>
      `).join("")}</tbody>
    </table>`;
}

async function loadCandles(symbol) {
  const out = await api(`/api/data/candles?symbol=${encodeURIComponent(symbol)}`);
  drawChart(out.rows);
}

function drawChart(rows) {
  const canvas = $("#price-chart");
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.max(600, rect.width * dpr);
  canvas.height = 280 * dpr;
  const ctx = canvas.getContext("2d");
  ctx.scale(dpr, dpr);
  const w = canvas.width / dpr;
  const h = canvas.height / dpr;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#08111c";
  ctx.fillRect(0, 0, w, h);
  if (!rows.length) return;
  const pad = 30;
  const min = Math.min(...rows.map((r) => r.low));
  const max = Math.max(...rows.map((r) => r.high));
  const x = (i) => pad + (i / Math.max(1, rows.length - 1)) * (w - pad * 2);
  const y = (v) => h - pad - ((v - min) / Math.max(1e-9, max - min)) * (h - pad * 2);

  ctx.strokeStyle = "rgba(57,199,216,.12)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 5; i++) {
    const gy = pad + i * ((h - pad * 2) / 4);
    ctx.beginPath(); ctx.moveTo(pad, gy); ctx.lineTo(w - pad, gy); ctx.stroke();
  }
  const barW = Math.max(2, (w - pad * 2) / rows.length * 0.55);
  rows.forEach((r, i) => {
    const up = r.close >= r.open;
    ctx.strokeStyle = up ? "#45d18a" : "#e45d67";
    ctx.fillStyle = ctx.strokeStyle;
    const cx = x(i);
    ctx.beginPath(); ctx.moveTo(cx, y(r.low)); ctx.lineTo(cx, y(r.high)); ctx.stroke();
    const top = y(Math.max(r.open, r.close));
    const bottom = y(Math.min(r.open, r.close));
    ctx.fillRect(cx - barW / 2, top, barW, Math.max(1, bottom - top));
  });
  ctx.fillStyle = "#7e8da4";
  ctx.font = "12px Segoe UI";
  ctx.fillText(max.toFixed(2), 6, pad + 4);
  ctx.fillText(min.toFixed(2), 6, h - pad);
}

async function loadTrainingReport() {
  const report = await api("/api/train/report");
  if (report.status === "missing") return;
  state.training = report;
  $("#test-accuracy").textContent = fmtPct(report.metrics.test.accuracy);
  $("#bt-return").textContent = fmtPct(report.backtest.totalReturn);
  $("#bt-dd").textContent = fmtPct(report.backtest.maxDrawdown);
  $("#train-status").textContent = "已完成";
  $("#training-report").textContent = [
    `生成时间: ${report.generatedAt}`,
    `数据源: ${report.data.sourceName}`,
    `样本行: ${report.data.summary.totalRows}`,
    `训练样本: ${report.metrics.train.samples}`,
    `测试样本: ${report.metrics.test.samples}`,
    `测试准确率: ${fmtPct(report.metrics.test.accuracy)}`,
    `多头信号平均未来收益: ${fmtPct(report.metrics.test.avgFutureReturnLongSignal)}`,
    `空头信号平均未来收益: ${fmtPct(report.metrics.test.avgFutureReturnShortSignal)}`,
    `简化回测收益: ${fmtPct(report.backtest.totalReturn)}`,
    `最大回撤: ${fmtPct(report.backtest.maxDrawdown)}`,
    `交易次数: ${report.backtest.trades}`,
    "",
    "特征:",
    report.featureEngineering.features.join(", "),
    "",
    "风控说明:",
    report.riskNotes.join("\n")
  ].join("\n");
}

async function runTraining() {
  $("#train-status").textContent = "训练中";
  $("#training-report").textContent = "正在下载/读取数据、构建特征、训练逻辑回归并运行简化回测...";
  const report = await api("/api/train", {
    method: "POST",
    body: JSON.stringify({
      epochs: Number($("#epochs").value),
      learningRate: Number($("#learning-rate").value),
      l2: Number($("#l2").value)
    })
  });
  state.training = report;
  await loadTrainingReport();
}

function pushMessage(role, text) {
  state.messages.push({ role, content: text });
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.textContent = text;
  $("#messages").appendChild(div);
  $("#messages").scrollTop = $("#messages").scrollHeight;
}

async function sendChat() {
  const input = $("#chat-input");
  const text = input.value.trim();
  if (!text) return;
  input.value = "";
  pushMessage("user", text);
  const waiting = document.createElement("div");
  waiting.className = "msg assistant";
  waiting.textContent = "分析中...";
  $("#messages").appendChild(waiting);
  try {
    const out = await api("/api/chat", {
      method: "POST",
      body: JSON.stringify({ messages: state.messages.slice(-10) })
    });
    const content = out.choices?.[0]?.message?.content || JSON.stringify(out, null, 2);
    waiting.textContent = content;
    state.messages.push({ role: "assistant", content });
  } catch (error) {
    waiting.textContent = `模型调用失败：${error.message}`;
  }
}

async function loadModelConfig() {
  const c = await api("/api/model");
  $("#provider").value = c.provider;
  $("#base-url").value = c.baseUrl;
  $("#api-key").value = c.apiKeyMasked;
  $("#model").value = c.model;
  $("#temperature").value = c.temperature;
  $("#max-tokens").value = c.maxTokens;
  $("#system-prompt").value = c.systemPrompt;
}

async function saveModelConfig() {
  const out = await api("/api/model", {
    method: "POST",
    body: JSON.stringify({
      provider: $("#provider").value,
      baseUrl: $("#base-url").value,
      apiKey: $("#api-key").value,
      model: $("#model").value,
      temperature: Number($("#temperature").value),
      maxTokens: Number($("#max-tokens").value),
      systemPrompt: $("#system-prompt").value
    })
  });
  $("#model-save-result").textContent = JSON.stringify(out, null, 2);
}

async function riskCheck() {
  const out = await api("/api/risk/check", {
    method: "POST",
    body: JSON.stringify({
      symbol: $("#risk-symbol").value,
      quantity: Number($("#risk-qty").value),
      leverage: Number($("#risk-lev").value),
      stopLossPct: Number($("#risk-sl").value),
      intent: $("#risk-intent").value
    })
  });
  $("#risk-result").textContent = JSON.stringify(out, null, 2);
}

function bind() {
  $$(".nav-item").forEach((b) => b.addEventListener("click", () => switchPanel(b.dataset.panel)));
  $("#symbol-select").addEventListener("change", (e) => loadCandles(e.target.value));
  $("#refresh-data").addEventListener("click", () => loadData(true).catch(alert));
  $("#run-training").addEventListener("click", () => runTraining().catch((e) => { $("#training-report").textContent = e.message; $("#train-status").textContent = "失败"; }));
  $("#run-training-top").addEventListener("click", () => { switchPanel("training"); runTraining().catch(alert); });
  $("#send-chat").addEventListener("click", () => sendChat());
  $("#chat-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) sendChat();
  });
  $("#save-model").addEventListener("click", () => saveModelConfig().catch((e) => { $("#model-save-result").textContent = e.message; }));
  $("#risk-check").addEventListener("click", () => riskCheck().catch((e) => { $("#risk-result").textContent = e.message; }));
}

bind();
await loadHealth();
await loadData(false);
await loadTrainingReport().catch(() => {});
await loadModelConfig();
